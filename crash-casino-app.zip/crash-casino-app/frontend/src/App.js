import React, { useState, useEffect, useRef, useCallback } from 'react';
import './App.css';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;
const WS_URL = `${BACKEND_URL}/api/ws`.replace('http', 'ws');

function App() {
  const [user, setUser] = useState(null);
  const [gameState, setGameState] = useState('waiting');
  const [multiplier, setMultiplier] = useState(1.0);
  const [countdown, setCountdown] = useState(10);
  const [betAmount, setBetAmount] = useState(10);
  const [hasBet, setHasBet] = useState(false);
  const [liveBets, setLiveBets] = useState([]);
  const [gameHistory, setGameHistory] = useState([]);
  const [streak, setStreak] = useState({ type: 'none', count: 0 });
  const [message, setMessage] = useState('Connecting...');
  const [multiplierHistory, setMultiplierHistory] = useState([]);
  
  const wsRef = useRef(null);
  const canvasRef = useRef(null);
  const currentBetRef = useRef(null);

  // Initialize user
  useEffect(() => {
    initUser();
  }, []);

  const initUser = async () => {
    try {
      // Get Telegram user data if available
      let telegramId = null;
      let username = 'Player';
      
      if (window.Telegram?.WebApp) {
        const tg = window.Telegram.WebApp;
        tg.ready();
        tg.expand();
        
        if (tg.initDataUnsafe?.user) {
          telegramId = String(tg.initDataUnsafe.user.id);
          username = tg.initDataUnsafe.user.first_name || 'Player';
        }
      }
      
      // Create or get user
      const params = new URLSearchParams();
      if (telegramId) params.append('telegram_id', telegramId);
      params.append('username', username);
      
      const response = await fetch(`${API}/user/create?${params}`, {
        method: 'POST'
      });
      const userData = await response.json();
      setUser(userData);
      
      // Connect to WebSocket
      connectWebSocket();
    } catch (error) {
      console.error('Failed to init user:', error);
      setMessage('Connection failed. Retrying...');
      setTimeout(initUser, 3000);
    }
  };

  const connectWebSocket = () => {
    const ws = new WebSocket(WS_URL);
    
    ws.onopen = () => {
      console.log('WebSocket connected');
      setMessage('Connected!');
    };
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      handleWebSocketMessage(data);
    };
    
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    ws.onclose = () => {
      console.log('WebSocket disconnected. Reconnecting...');
      setTimeout(connectWebSocket, 3000);
    };
    
    wsRef.current = ws;
  };

  const handleWebSocketMessage = (data) => {
    switch (data.type) {
      case 'connected':
        setGameState(data.game_state);
        if (data.history) {
          setGameHistory(data.history.recent_crashes || []);
          setStreak(data.history.streak);
        }
        break;
        
      case 'waiting':
        setGameState('waiting');
        setCountdown(data.countdown);
        setMessage(data.message);
        setMultiplier(1.0);
        setMultiplierHistory([]);
        setHasBet(false);
        currentBetRef.current = null;
        break;
        
      case 'game_started':
        setGameState('playing');
        setMessage(data.message);
        setMultiplierHistory([{ time: 0, value: 1.0 }]);
        break;
        
      case 'multiplier_update':
        setMultiplier(data.multiplier);
        setMultiplierHistory(prev => [...prev, { time: data.elapsed_time, value: data.multiplier }]);
        break;
        
      case 'game_crashed':
        setGameState('crashed');
        setMessage(`CRASHED at ${data.crash_point}x!`);
        setLiveBets(data.bets || []);
        if (data.history) {
          setGameHistory(data.history.recent_crashes || []);
          setStreak(data.history.streak);
        }
        // Refresh user balance
        if (user) {
          refreshUser();
        }
        break;
        
      case 'bet_placed':
        setLiveBets(prev => [...prev, data.bet]);
        if (data.bet.user_id === user?.id) {
          currentBetRef.current = data.bet;
        }
        break;
        
      case 'cash_out':
        setLiveBets(prev => prev.map(bet => 
          bet.user_id === data.bet.user_id ? data.bet : bet
        ));
        if (data.bet.user_id === user?.id) {
          setHasBet(false);
          currentBetRef.current = null;
        }
        break;
    }
  };

  const refreshUser = async () => {
    if (!user) return;
    try {
      const response = await fetch(`${API}/user/${user.id}`);
      const userData = await response.json();
      setUser(userData);
    } catch (error) {
      console.error('Failed to refresh user:', error);
    }
  };

  const placeBet = async () => {
    if (!user || hasBet || gameState !== 'waiting') return;
    
    try {
      const response = await fetch(`${API}/game/bet`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user.id,
          username: user.username,
          amount: betAmount
        })
      });
      
      const result = await response.json();
      if (result.success) {
        setUser(prev => ({ ...prev, balance: result.new_balance }));
        setHasBet(true);
        currentBetRef.current = result.bet;
      }
    } catch (error) {
      console.error('Failed to place bet:', error);
    }
  };

  const cashOut = async () => {
    if (!user || !hasBet || gameState !== 'playing') return;
    
    try {
      const response = await fetch(`${API}/game/cashout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: user.id })
      });
      
      const result = await response.json();
      if (result.success) {
        setUser(prev => ({ ...prev, balance: result.new_balance }));
        setHasBet(false);
      }
    } catch (error) {
      console.error('Failed to cash out:', error);
    }
  };

  // Draw graph
  useEffect(() => {
    if (!canvasRef.current || multiplierHistory.length === 0) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    
    // Clear canvas
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, height);
    
    // Draw grid
    ctx.strokeStyle = '#1a1a1a';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 10; i++) {
      const y = (height / 10) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
    
    // Draw line
    if (multiplierHistory.length > 1) {
      const maxTime = multiplierHistory[multiplierHistory.length - 1].time;
      const maxValue = Math.max(...multiplierHistory.map(h => h.value));
      
      ctx.strokeStyle = gameState === 'crashed' ? '#ef4444' : '#22c55e';
      ctx.lineWidth = 3;
      ctx.beginPath();
      
      multiplierHistory.forEach((point, index) => {
        const x = (point.time / maxTime) * width;
        const y = height - ((point.value / maxValue) * height * 0.9);
        
        if (index === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      
      ctx.stroke();
      
      // Draw glow effect
      ctx.shadowBlur = 20;
      ctx.shadowColor = gameState === 'crashed' ? '#ef4444' : '#22c55e';
      ctx.stroke();
    }
  }, [multiplierHistory, gameState]);

  return (
    <div className="app" data-testid="crash-casino-app">
      {/* Header */}
      <header className="header">
        <div className="header-content">
          <h1 className="logo" data-testid="app-title">⚡ MYUPSTAKE</h1>
          {user && (
            <div className="user-info" data-testid="user-info">
              <div className="username">{user.username}</div>
              <div className="balance" data-testid="user-balance">
                ⭐ {user.balance.toFixed(2)}
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Game Area */}
      <main className="main-content">
        {/* Game Canvas */}
        <div className="game-section">
          <div className="canvas-container" data-testid="game-canvas-container">
            <canvas 
              ref={canvasRef} 
              width={800} 
              height={400}
              className="game-canvas"
            />
            
            <div className="multiplier-display" data-testid="multiplier-display">
              <div className={`multiplier ${gameState}`}>
                {multiplier.toFixed(2)}x
              </div>
              <div className="game-message">{message}</div>
            </div>
            
            {gameState === 'waiting' && (
              <div className="countdown" data-testid="countdown-display">
                {countdown}
              </div>
            )}
          </div>

          {/* Betting Controls */}
          <div className="controls" data-testid="betting-controls">
            <div className="bet-input-group">
              <label>Bet Amount (⭐)</label>
              <div className="input-with-buttons">
                <button 
                  onClick={() => setBetAmount(Math.max(1, betAmount / 2))}
                  disabled={hasBet || gameState !== 'waiting'}
                  className="adjust-btn"
                >
                  ½
                </button>
                <input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(Number(e.target.value))}
                  disabled={hasBet || gameState !== 'waiting'}
                  min="1"
                  className="bet-input"
                  data-testid="bet-amount-input"
                />
                <button 
                  onClick={() => setBetAmount(betAmount * 2)}
                  disabled={hasBet || gameState !== 'waiting'}
                  className="adjust-btn"
                >
                  2×
                </button>
              </div>
            </div>

            {!hasBet ? (
              <button
                onClick={placeBet}
                disabled={gameState !== 'waiting' || !user || betAmount > user?.balance}
                className="action-btn place-bet"
                data-testid="place-bet-btn"
              >
                Place Bet
              </button>
            ) : (
              <button
                onClick={cashOut}
                disabled={gameState !== 'playing'}
                className="action-btn cash-out"
                data-testid="cash-out-btn"
              >
                Cash Out @ {multiplier.toFixed(2)}x
              </button>
            )}
          </div>
        </div>

        {/* Side Panel */}
        <aside className="side-panel">
          {/* Game History */}
          <div className="panel-section" data-testid="game-history">
            <h3>History</h3>
            <div className="history-list">
              {gameHistory.slice(-10).reverse().map((crash, index) => (
                <div 
                  key={index} 
                  className={`history-item ${crash >= 2.0 ? 'high' : 'low'}`}
                >
                  {crash.toFixed(2)}x
                </div>
              ))}
            </div>
            {streak.count > 0 && (
              <div className="streak" data-testid="streak-indicator">
                {streak.type === 'high' ? '🔥' : '❄️'} Streak: {streak.count}
              </div>
            )}
          </div>

          {/* Live Bets */}
          <div className="panel-section" data-testid="live-bets">
            <h3>Live Bets</h3>
            <div className="bets-list">
              {liveBets.slice(-8).reverse().map((bet, index) => (
                <div key={index} className="bet-item">
                  <div className="bet-user">{bet.username}</div>
                  <div className="bet-amount">⭐{bet.amount}</div>
                  {bet.status === 'cashed_out' && (
                    <div className="bet-result win">
                      {bet.cash_out_multiplier.toFixed(2)}x
                      <span className="profit">+{bet.profit.toFixed(2)}</span>
                    </div>
                  )}
                  {bet.status === 'lost' && (
                    <div className="bet-result loss">LOST</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </aside>
      </main>
    </div>
  );
}

export default App;
