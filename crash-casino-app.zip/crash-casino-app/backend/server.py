from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, APIRouter
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
import os
import asyncio
import json
import uuid
from pathlib import Path
from dotenv import load_dotenv

from game_logic import CrashGame

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Game instance
game = CrashGame()
game_task = None
connected_clients = set()

# Models
class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    telegram_id: Optional[str] = None
    username: str
    balance: float = 1000.0  # Starting balance in stars
    total_wagered: float = 0.0
    total_won: float = 0.0
    games_played: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)

class PlaceBetRequest(BaseModel):
    user_id: str
    username: str
    amount: float

class CashOutRequest(BaseModel):
    user_id: str

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except:
                pass

manager = ConnectionManager()

# Game loop
async def game_loop():
    """Main game loop that runs crash games continuously"""
    while True:
        try:
            # Waiting phase (10 seconds)
            game.game_state = "waiting"
            game.bets = []
            
            for i in range(10, 0, -1):
                await manager.broadcast({
                    "type": "waiting",
                    "countdown": i,
                    "message": f"Game starting in {i}s..."
                })
                await asyncio.sleep(1)
            
            # Start game
            crash_point = game.start_game()
            await manager.broadcast({
                "type": "game_started",
                "message": "Game started! Good luck!"
            })
            
            # Playing phase
            start_time = asyncio.get_event_loop().time()
            while game.game_state == "playing":
                elapsed = asyncio.get_event_loop().time() - start_time
                current_multiplier = game.update_multiplier(elapsed)
                
                await manager.broadcast({
                    "type": "multiplier_update",
                    "multiplier": current_multiplier,
                    "elapsed_time": round(elapsed, 2)
                })
                
                # Check if game should crash
                if game.game_state == "crashed":
                    break
                
                await asyncio.sleep(0.05)  # Update 20 times per second
            
            # Game crashed
            game_result = game.end_game()
            history_stats = game.get_history_stats()
            
            await manager.broadcast({
                "type": "game_crashed",
                "crash_point": crash_point,
                "bets": game_result["bets"],
                "history": history_stats
            })
            
            # Show crash screen for 5 seconds
            await asyncio.sleep(5)
            
        except Exception as e:
            print(f"Error in game loop: {e}")
            await asyncio.sleep(1)

# API Routes
@api_router.get("/")
async def root():
    return {"message": "MYUPSTAKE Casino API", "version": "1.0"}

@api_router.post("/user/create", response_model=User)
async def create_user(telegram_id: Optional[str] = None, username: str = "Player"):
    """Create a new user or get existing"""
    # Check if user exists
    if telegram_id:
        existing_user = await db.users.find_one({"telegram_id": telegram_id})
        if existing_user:
            existing_user.pop('_id', None)
            return User(**existing_user)
    
    # Create new user
    user = User(telegram_id=telegram_id, username=username)
    user_dict = user.model_dump()
    user_dict['created_at'] = user_dict['created_at'].isoformat()
    
    await db.users.insert_one(user_dict)
    return user

@api_router.get("/user/{user_id}", response_model=User)
async def get_user(user_id: str):
    """Get user by ID"""
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if isinstance(user.get('created_at'), str):
        user['created_at'] = datetime.fromisoformat(user['created_at'])
    
    return User(**user)

@api_router.post("/game/bet")
async def place_bet(bet_request: PlaceBetRequest):
    """Place a bet in the current game"""
    # Check if game is in waiting state
    if game.game_state != "waiting":
        raise HTTPException(status_code=400, detail="Cannot place bet now")
    
    # Get user and check balance
    user = await db.users.find_one({"id": bet_request.user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if user["balance"] < bet_request.amount:
        raise HTTPException(status_code=400, detail="Insufficient balance")
    
    # Place bet
    bet = game.place_bet(bet_request.user_id, bet_request.username, bet_request.amount)
    
    # Update user balance
    new_balance = user["balance"] - bet_request.amount
    await db.users.update_one(
        {"id": bet_request.user_id},
        {"$set": {"balance": new_balance}, "$inc": {"total_wagered": bet_request.amount}}
    )
    
    # Broadcast bet to all clients
    await manager.broadcast({
        "type": "bet_placed",
        "bet": bet
    })
    
    return {"success": True, "bet": bet, "new_balance": new_balance}

@api_router.post("/game/cashout")
async def cash_out(cashout_request: CashOutRequest):
    """Cash out at current multiplier"""
    if game.game_state != "playing":
        raise HTTPException(status_code=400, detail="Cannot cash out now")
    
    # Cash out
    bet = game.cash_out(cashout_request.user_id, game.current_multiplier)
    if not bet:
        raise HTTPException(status_code=400, detail="No active bet found")
    
    # Update user balance
    payout = bet["amount"] * bet["cash_out_multiplier"]
    user = await db.users.find_one({"id": cashout_request.user_id})
    new_balance = user["balance"] + payout
    
    await db.users.update_one(
        {"id": cashout_request.user_id},
        {
            "$set": {"balance": new_balance},
            "$inc": {"total_won": bet["profit"], "games_played": 1}
        }
    )
    
    # Broadcast cashout to all clients
    await manager.broadcast({
        "type": "cash_out",
        "bet": bet
    })
    
    return {"success": True, "bet": bet, "new_balance": new_balance}

@api_router.get("/game/history")
async def get_game_history():
    """Get game history and statistics"""
    return game.get_history_stats()

@api_router.get("/game/state")
async def get_game_state():
    """Get current game state"""
    return {
        "state": game.game_state,
        "multiplier": game.current_multiplier,
        "bets": game.bets
    }

# WebSocket endpoint
@api_router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        # Send current game state
        await websocket.send_json({
            "type": "connected",
            "game_state": game.game_state,
            "multiplier": game.current_multiplier,
            "history": game.get_history_stats()
        })
        
        # Keep connection alive
        while True:
            data = await websocket.receive_text()
            # Echo back for heartbeat
            await websocket.send_text(data)
    except WebSocketDisconnect:
        manager.disconnect(websocket)

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    """Start game loop on server startup"""
    global game_task
    game_task = asyncio.create_task(game_loop())

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    if game_task:
        game_task.cancel()
    client.close()
